
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Online Voting System Access Denied</title>
<link href="css/admin_styles.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="tan">
<center><a href =""></a></center><br>     
<center><b><font color = "brown" size="6">Online Voting System</font></b></center><br><br>
<body>
<div id="page">
<div id="header">
  <h1>Access Denied</h1>
  <a href="admin.php">Home</a>  <a href="manage-admins.php"></a>  <a href="positions.php"></a>  <a href="candidates.php"></a>  <a href="results.php"></a>
</div>
<div id="container">
<div class="err">Access Denied!</div>
  <p>You don't have access to this resource. <a href="index.php">Click here</a> to login first.</p>
</div>
<div id="footer"> 
  <div class="bottom_addr">&copy; 2018 Online Voting System. All Rights Reserved</div>
</div>
</div>
</body>
</html>
