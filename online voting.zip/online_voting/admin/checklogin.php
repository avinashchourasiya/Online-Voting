<!DOCTYPE html>
<html>
<head>

<title>Online Voting System Access Denied</title>
<link href="css/admin_styles.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="tan">
<center><b><font color = "brown" size="6">Online Voting System</font></b></center><br><br>
<body>
<div id="page">
<div id="header">
<h1>Invalid Credentials Provided </h1>
<p align="center">&nbsp;</p>
</div>
<div id="container">
<?php
ini_set ("display_errors", "1");
error_reporting(E_ALL);

ob_start();
session_start();
require('../connection.php');




// Defining your login details into variables
$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];
$encrypted_mypassword=md5($mypassword); //MD5 Hash for security
// MySQL injection protections
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysqli_real_escape_string($con,$myusername);
$mypassword = mysqli_real_escape_string($con,$mypassword);

$sql="SELECT email,password FROM tbAdministrators WHERE email='$myusername' and password='$mypassword'";
$result=mysqli_query($con,$sql);

// Checking table row
$count=mysqli_num_rows($result);
// If username and password is a match, the count will be 1
echo($count);
if($count==1){
// If everything checks out, you will now be forwarded to admin.php
//$user = mysqli_fetch_assoc($result);
 //$_SESSION['admin_id'] = $user['admin_id'];
header("location:admin.php");}
//echo "string";}
//If the username or password is wrong, you will receive this message below.
else {
echo "Wrong Username or Password<br><br>Return to <a href=\"index.php\">login</a>";
}





?> 
</div>
<div id="footer"> 
  <div class="bottom_addr">&copy; 2018 Online Voting System. All Rights Reserved</div>
</div>
</div>
</body>
</html>