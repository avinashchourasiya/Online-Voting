
<?php
if(empty($_GET['uname']))
{
	header("location:test.php");
	die();
}
$a=$_GET['uname'];
//(isset($_GET['submit']))

	echo($a);
//header("location:test1.php")
?>
