<?php
$con=mysqli_connect("localhost","root","","poll");
if(!$con)
{
	die(mysqli_error($con));
echo("done1");
}
?>