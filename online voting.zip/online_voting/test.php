<!DOCTYPE html>

<html>
<head>
	<title></title>
</head>
<body>
<form action="test.php" method="post">
<input type="text" name="uname">
<input type="submit" name="submit">
</form>
</body>
<?php


//On page 1


//On page 2

if(isset($_POST['submit']))
{
		$a=$_POST['uname'];
		$url="test1.php?uname=$a";
		header("location:$url");
		exit();
	}


?>
</html>