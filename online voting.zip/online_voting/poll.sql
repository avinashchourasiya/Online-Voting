-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2018 at 05:58 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poll`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadministrators`
--

CREATE TABLE `tbadministrators` (
  `admin_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbadministrators`
--

INSERT INTO `tbadministrators` (`admin_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'Kimani', 'Kahiga', 'admin@example.com', '1234'),
(2, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `tbcandidates`
--

CREATE TABLE `tbcandidates` (
  `candidate_id` int(5) NOT NULL,
  `candidate_name` varchar(45) NOT NULL,
  `candidate_position` varchar(45) NOT NULL,
  `candidate_cvotes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcandidates`
--

INSERT INTO `tbcandidates` (`candidate_id`, `candidate_name`, `candidate_position`, `candidate_cvotes`) VALUES
(25, 'Nandini', 'Employee', 1),
(26, 'Namrata', 'Employee', 1),
(27, 'Pinto', 'Employee', 0),
(28, 'Harshan', 'Employee', 0),
(29, 'Raj', 'Employee', 0),
(30, 'Mr.Karan Jha', 'CMO', 6),
(31, 'Mr. Harshit singh', 'Management-Head', 0),
(32, 'Mr.shreyash Pandey', 'Project_Manager', 0),
(33, 'Miss. Vibhangi ', 'SQL_Programmers-Lead', 0),
(35, 'Mr.Karan Jha-2', 'CMO', 1),
(36, 'Miss. Vibhangi-2', 'SQL_Programmers-Lead', 0),
(37, 'Mr. Harshit singh-2', 'Management-Head', 0),
(39, 'Mr.shreyash Pandey-2', 'Project_Manager', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbmembers`
--

CREATE TABLE `tbmembers` (
  `member_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbmembers`
--

INSERT INTO `tbmembers` (`member_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'Kimani', 'Kahiga', 'kahiga@gmail.com', '1234'),
(2, 'MacDonald', 'Ngowi', 'mcbcrue08@gmail.com', '14b876400a7ae986df9b17fbaffb9eca'),
(3, 'test', 'testt', 'test@example.com', '098f6bcd4621d373cade4e832627b4f6'),
(5, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', '1234'),
(6, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(7, 'ayay', 'ayay', 'asas@gmail.com', '71f449d78070b8dd0805aca530794cce'),
(8, 'ayay', 'ayay', 'asas@gmail.com', '71f449d78070b8dd0805aca530794cce'),
(9, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', 'f795e34c94384805f4e8da7d98effc81'),
(10, 'Avinash1', 'chourasiya1', 'avinashchourasiya88@gmail.com', '8c0e89c1abfd7b6b877331ff3307e1cd'),
(11, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', 'a72a24c68096b5dc77eb4072c7532a29'),
(12, 'Avinash1', 'chourasiya1', 'avinashchourasiya88@gmail.com', 'c58af20903f165a77e465fd111333f6a'),
(13, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', '1a604da008c5b755ad064d9e7c8682c3'),
(14, 'Avinash', 'chourasiya', 'avinashchourasiya88@gmail.com', '1232');

-- --------------------------------------------------------

--
-- Table structure for table `tbpositions`
--

CREATE TABLE `tbpositions` (
  `position_id` int(5) NOT NULL,
  `position_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpositions`
--

INSERT INTO `tbpositions` (`position_id`, `position_name`) VALUES
(17, 'Employee'),
(18, 'CMO'),
(19, 'Management-Head'),
(22, 'Project_Manager'),
(23, 'programmers_lead'),
(24, 'SQL_Programmers-Lead');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Indexes for table `tbmembers`
--
ALTER TABLE `tbmembers`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `tbpositions`
--
ALTER TABLE `tbpositions`
  ADD PRIMARY KEY (`position_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  MODIFY `admin_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  MODIFY `candidate_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tbmembers`
--
ALTER TABLE `tbmembers`
  MODIFY `member_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbpositions`
--
ALTER TABLE `tbpositions`
  MODIFY `position_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
