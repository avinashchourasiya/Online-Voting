<html><head>
<link href="css/user_styles.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/user.js">
</script>
</head><body bgcolor="tan">
   
<center><b><font color = "brown" size="6">Online Voting System</font></b></center><br><br>
<div id="page">
<div id="header">
<h1>Student Registration </h1>
<div class="news"><marquee behavior="alternate">New polls are up and running. But they will not be up forever! Just Login and then go to Current Polls to vote for your favourate candidates. </marquee></div>
</div>
<div id="container">
	<form method="post" action="registeracc.php">
<table>
	<tr><td>firstname:</td>
		<td><input type="text" name="fname" maxlength="15" required></td>
	</tr>
	<tr><td>lastname:</td>
		<td><input type="text" name="lname" maxlength="15" required></td>
	</tr>
		<tr>
			<td>Email:</td>
		<td><input type="email" name="email" maxlength="" required></td>
	</tr>
	<tr><td>password:</td>
		<td><input type="password" name="password" maxlength="15" required></td>
	</tr>
		<tr><td></td><td><input type="submit" name="submit"></td>
			<tr></tr><tr></tr>

	</tr>
		<tr><td></td><td><a href="index.php" style="font-size:1em;">Click to login</a><td>
	</tr>
</table>
</form>
</div>
</div> 
</div>
</body>
<?php
require('connection.php');
//Process
if (isset($_POST['submit']))
{
$myFirstName = addslashes( $_POST['fname'] ); //prevents types of SQL injection
$myLastName = addslashes( $_POST['lname'] ); //prevents types of SQL injection
$myEmail = $_POST['email'];
$myPassword = $_POST['password'];
$newpass = md5($myPassword); //This will make your password encrypted into md5, a high security hash
$insert="INSERT INTO tbMembers(first_name,last_name,email,password)VALUES('$myFirstName','$myLastName','$myEmail','$myPassword')";

if(mysqli_query($con,$insert))
{
 ?> <script>alert("You have registerd successfully\n Note:");</script><?php
 
}
else{
        die("done error".mysqli_error($con));

//die( "You have registered for an account.<br><br>Go to <a href=\"login.html\">Login</a>" );
    }
}
if(isset($_POST['login']))
{
	header("location:index.php");
}
?>



<div id="footer">
<div class="bottom_addr">&copy; Online Voting System. All Rights Reserved</div>
</div>
</div>
</body></html>