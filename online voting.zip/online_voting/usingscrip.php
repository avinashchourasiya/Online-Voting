<?php
$a=2;
if($a%2==0){
echo "<script>alert(Number is Even);</script>";
}
else {
echo "<script>alert(Number is Odd);</script>";
}
?>