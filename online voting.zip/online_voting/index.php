<html><head>
<link href="css/user_styles.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/user.js">
</script>
</head><body bgcolor="tan">
<?php
$z;
include "connection.php";
if(isset($_POST['Submit']))
{
$a=$_POST['username'];
$b=$_POST['password'];
$select="select email,password from tbmembers where email='$a' and password='$b'";
$result=mysqli_query($con, $select);
$user = mysqli_fetch_assoc($result);
if(mysqli_num_rows($result) > 0)
{
//$_SESSION['email'] = $user['email'];
$url="student.php?username=$a";
$url1="manage-profile.php?username=$a";
header("location:$url");
//header("location:$url1");
}
else{
	echo("invalid credentials");
	header("location:access-denied.php");
	echo (mysqli_error($con));
	
	
//	 die();
}
mysqli_close($con);
}
?>





<center><b><font color = "brown" size="6">Online Voting System</font></b></center><br><br>
<div id="page">
<div id="header">
<h1>Student Login </h1>
<div class="news"><marquee behavior="alternate">New polls are up and running. But they will not be up forever! Just Login and then go to Current Polls to vote for your favourate candidates. </marquee></div>
</div>
<div id="container">
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<form name="form1" method="post" action="index.php" onSubmit="">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="tan">
<tr>
<td width="78">Username/Email</td>
<td width="6">:</td>
<td width="294"><input name="username" type="text" id="username"></td>
</tr>
<tr>
<td>Password</td>
<td>:</td>
<td><input name="password" type="password" id="password"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Login"></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<center>
<br>Not yet registered? <a href="registeracc.php"><b>Register Here</b></a>
<?php echo("<h6 style=color:red;></h6>");?>
</center>
</div>
<div id="footer">
<div class="bottom_addr">&copy; 2018 Online Voting System. All Rights Reserved</div>
</div>
</div>
</body></html>